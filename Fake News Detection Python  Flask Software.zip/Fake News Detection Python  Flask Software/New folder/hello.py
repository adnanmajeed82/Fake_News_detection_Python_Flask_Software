print("hello world")
print("2+2")